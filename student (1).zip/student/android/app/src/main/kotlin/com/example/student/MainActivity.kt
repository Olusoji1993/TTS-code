package com.example.student

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
