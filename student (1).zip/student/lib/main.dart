import 'dart:async';
import 'dart:io';
import 'package:ed_screen_recorder/ed_screen_recorder.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:student/recorded_video.dart';
import 'package:student/saved_text.dart';
import 'package:student/settings_screen.dart';
import 'package:student/theme_provider.dart';
import 'package:alan_voice/alan_voice.dart';
import 'package:student/video_player.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final sp = await SharedPreferences.getInstance();
  final int? colorValue = sp.getInt('theme_color');
  final double? size = sp.getDouble('font_size');
  Color initialColor = colorValue != null
      ? Color(colorValue)
      : const Color.fromARGB(255, 2, 99, 181);
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider<ThemeProvider>(
      create: (_) => ThemeProvider(initialColor, size ?? 16),
    ),
  ], child: const MyApp()));
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final themeData = ThemeData(
      fontFamily: AppTheme.fontName,
      scaffoldBackgroundColor: themeProvider.primaryColor,
      appBarTheme: AppBarTheme(
          actionsIconTheme: IconThemeData(
              color: themeProvider.primaryColor.computeLuminance() > .3
                  ? Colors.black
                  : Colors.white),
          iconTheme: IconThemeData(
              color: themeProvider.primaryColor.computeLuminance() > .3
                  ? Colors.black
                  : Colors.white),
          titleTextStyle: TextStyle(
              fontSize: 20,
              fontFamily: AppTheme.fontName,
              fontWeight: FontWeight.bold,
              color: themeProvider.primaryColor.computeLuminance() > .3
                  ? Colors.black
                  : Colors.white),
          backgroundColor: themeProvider.primaryColor.withOpacity(.5),
          shadowColor: Colors.black,
          elevation: 5),
      useMaterial3: true,
      primarySwatch: MaterialColor(
        themeProvider.primaryColor.value,
        <int, Color>{
          50: themeProvider.primaryColor.withOpacity(0.1),
          100: themeProvider.primaryColor.withOpacity(0.2),
          200: themeProvider.primaryColor.withOpacity(0.3),
          300: themeProvider.primaryColor.withOpacity(0.4),
          400: themeProvider.primaryColor.withOpacity(0.5),
          500: themeProvider.primaryColor.withOpacity(0.6),
          600: themeProvider.primaryColor.withOpacity(0.7),
          700: themeProvider.primaryColor.withOpacity(0.8),
          800: themeProvider.primaryColor.withOpacity(0.9),
          900: themeProvider.primaryColor,
        },
      ),
      textTheme: AppTheme.textTheme,
    );
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness:
          !kIsWeb && Platform.isAndroid ? Brightness.dark : Brightness.light,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarDividerColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.dark,
    ));
    return MaterialApp(
      theme: themeData,
      debugShowCheckedModeBanner: false,
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  EdScreenRecorder? screenRecorder;
  Map<String, dynamic>? _response;
  bool inProgress = false;
  bool startTTS = false;
  String appDocPath = '';
  late List<FileSystemEntity> files;

  @override
  void initState() {
    getData();
    initTts();

    _MyHomePageState();
    super.initState();
    screenRecorder = EdScreenRecorder();
  }

  Future<void> getData() async {
    Directory? appDocDirectory = await getApplicationDocumentsDirectory();
    appDocPath = appDocDirectory.path;
  }

  Future<void> startRecord({required String fileName}) async {
    Directory? tempDir = await getApplicationDocumentsDirectory();
    String? tempPath = tempDir.path;
    try {
      var startResponse = await screenRecorder?.startRecordScreen(
        fileName: fileName,
        dirPathToSave: tempPath,
        audioEnable: false,
      );
      setState(() {
        _response = startResponse;
        inProgress = true;
      });
    } on PlatformException {
      setState(() {
        inProgress = false;
      });
      if (kDebugMode) {
        debugPrint("Error: An error occurred while starting the recording!");
        print("Error: $_response");
      }
    }
  }

  Future<void> stopRecord() async {
    try {
      var stopResponse = await screenRecorder?.stopRecord();
      setState(() {
        _response = stopResponse;
        inProgress = false;
      });

      // ignore: use_build_context_synchronously
      showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ListTile(
                title: Text('Recording Stopped'),
                subtitle: Text('Recording has been successfully stopped.'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Close'),
              ),
            ],
          );
        },
      );
    } on PlatformException {
      setState(() {
        inProgress = true;
      });
      if (kDebugMode) {
        debugPrint("Error: An error occurred while stopping recording.");
        print("Error: $_response");
      }
    }
  }

  Future<void> pauseRecord() async {
    try {
      await screenRecorder?.pauseRecord();
      // ignore: use_build_context_synchronously
      showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ListTile(
                title: Text('Recording Paused'),
                subtitle: Text('Recording has been successfully paused.'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Close'),
              ),
            ],
          );
        },
      );
    } on PlatformException {
      kDebugMode
          ? debugPrint("Error: An error occurred while pause recording.")
          : null;
    }
  }

  Future<void> resumeRecord() async {
    try {
      await screenRecorder?.resumeRecord();
      // ignore: use_build_context_synchronously
      showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ListTile(
                title: Text('Recording Resumed'),
                subtitle: Text('Recording has been successfully resumed.'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Close'),
              ),
            ],
          );
        },
      );
    } on PlatformException {
      kDebugMode
          ? debugPrint("Error: An error occurred while resume recording.")
          : null;
    }
  }

  _MyHomePageState() {
    AlanVoice.addButton(
        "9ea1da0d1b1a3c12fd00186fb53201332e956eca572e1d8b807a3e2338fdd0dc/stage",
        buttonAlign: AlanVoice.BUTTON_ALIGN_RIGHT);

    AlanVoice.onCommand.add((command) => handleCommand(command.data));
  }

  void handleCommand(Map<String, dynamic> command) {
    switch (command["command"]) {
      case "start":
        startRecord(fileName: '');
        break;
      case "stop":
        stopRecord();
        break;
      case "pause":
        pauseRecord();
        break;
      case "resume":
        resumeRecord();
        break;
      case "settings":
        {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const SettingsScreen(),
            ),
          );
        }
        break;
      case "recorded":
        {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => RecordedVideosPage(appDocPath: appDocPath),
            ),
          );
        }
        break;
      case "back":
        {
          Navigator.pop(context);
        }
        break;
      case "video":
        {
          String indexAsString = command["text"];
          int index = 1;
          try {
            index = int.parse(indexAsString);
          } catch (e) {
            index = convertTextToNumber(indexAsString);
          }
          openVideoAtIndex(index);
        }
        break;
      default:
    }
  }

  int convertTextToNumber(String text) {
    Map<String, int> wordToNumber = {
      'zero': 0,
      'one': 1,
      'two': 2,
      'three': 3,
      'four': 4,
      'five': 5,
      'six': 6,
      'seven': 7,
      'eight': 8,
      'nine': 9,
      'ten': 10,
      'eleven': 11,
      'twelve': 12,
      'thirteen': 13,
      'fourteen': 14,
      'fifteen': 15,
      'sixteen': 16,
      'seventeen': 17,
      'eighteen': 18,
      'nineteen': 19,
      'twenty': 20,
    };

    String cleanedText = text.trim();

    int numericValue = wordToNumber[cleanedText] ?? 0;

    return numericValue;
  }

  void openVideoAtIndex(int index) async {
    files = await Directory(appDocPath).list().toList();
    index += 1;
    if (index >= 0 && index < files.length) {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => VideoPlayerPage(
            videoPath: files[index].path,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Center(child: Text("Student app")),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.settings),
              tooltip: 'Settings',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SettingsScreen(),
                  ),
                );
              },
            ),
          ],
        ),
        body: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                    ),
                    onPressed: () => setState(() {
                          startTTS = !startTTS;
                        }),
                    child: Text(
                      'START TTS',
                      style: themeProvider.title,
                    )),
                startTTS
                    ? Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 40.0, vertical: 20),
                            child: Container(
                              color: Colors.white,
                              child: TextField(
                                decoration: const InputDecoration(
                                    label: Text('write text')),
                                onChanged: (value) => setState(() {
                                  text = value;
                                }),
                              ),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 8.0),
                                child: FloatingActionButton(
                                  backgroundColor: Colors.green,
                                  onPressed: _speak,
                                  child: const Center(
                                    child: Icon(
                                      Icons.volume_up,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 8.0),
                                child: FloatingActionButton(
                                  backgroundColor: Colors.red,
                                  onPressed: _stop,
                                  child: const Center(
                                    child: Icon(
                                      Icons.stop,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 8.0),
                                child: FloatingActionButton(
                                  backgroundColor: Colors.blue,
                                  onPressed: _save,
                                  child: const Center(
                                    child: Icon(
                                      Icons.save,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      )
                    : Container(),
                const SizedBox(height: 10),
                ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                    ),
                    onPressed: () =>
                        startRecord(fileName: "Recording - ${DateTime.now()}"),
                    child: Text(
                      'START RECORD',
                      style: themeProvider.title,
                    )),
                inProgress
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: FloatingActionButton(
                              backgroundColor: Colors.yellow,
                              onPressed: pauseRecord,
                              child: const Center(
                                child: Icon(
                                  Icons.pause,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: FloatingActionButton(
                              backgroundColor: Colors.blue,
                              onPressed: resumeRecord,
                              child: const Center(
                                child: Icon(
                                  Icons.play_arrow_sharp,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: FloatingActionButton(
                              backgroundColor: Colors.red,
                              onPressed: stopRecord,
                              child: const Center(
                                child: Icon(
                                  Icons.stop,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                    : Container(),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            SavedTextPage(appDocPath: appDocPath),
                      ),
                    );
                  },
                  child: Text(
                    'OPEN SAVED TEXT',
                    textAlign: TextAlign.center,
                    style: themeProvider.title,
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            RecordedVideosPage(appDocPath: appDocPath),
                      ),
                    );
                  },
                  child: Text(
                    'OPEN RECORDED VIDEOS',
                    textAlign: TextAlign.center,
                    style: themeProvider.title,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  TtsState ttsState = TtsState.stopped;

  get isPlaying => ttsState == TtsState.playing;
  get isStopped => ttsState == TtsState.stopped;
  get isPaused => ttsState == TtsState.paused;
  get isContinued => ttsState == TtsState.continued;
  FlutterTts flutterTts = FlutterTts();
  bool isAndroid = true;
  final textRecognizer = TextRecognizer();
  String text = '';
  String? language;
  String? engine;
  double volume = 0.5;
  double pitch = 1.0;
  double rate = 0.5;

  initTts() {
    flutterTts = FlutterTts();

    _setAwaitOptions();

    if (isAndroid) {
      _getDefaultEngine();
      _getDefaultVoice();
    }

    flutterTts.setStartHandler(() {
      setState(() {
        print("Playing");
        ttsState = TtsState.playing;
      });
    });

    if (isAndroid) {
      flutterTts.setInitHandler(() {
        setState(() {
          print("TTS Initialized");
        });
      });
    }

    flutterTts.setCompletionHandler(() {
      setState(() {
        print("Complete");
        ttsState = TtsState.stopped;
      });
    });

    flutterTts.setCancelHandler(() {
      setState(() {
        print("Cancel");
        ttsState = TtsState.stopped;
      });
    });

    flutterTts.setPauseHandler(() {
      setState(() {
        print("Paused");
        ttsState = TtsState.paused;
      });
    });

    flutterTts.setContinueHandler(() {
      setState(() {
        print("Continued");
        ttsState = TtsState.continued;
      });
    });

    flutterTts.setErrorHandler((msg) {
      setState(() {
        print("error: $msg");
        ttsState = TtsState.stopped;
      });
    });
  }

  Future _getDefaultEngine() async {
    var engine = await flutterTts.getDefaultEngine;
    if (engine != null) {
      print(engine);
    }
  }

  Future _getDefaultVoice() async {
    var voice = await flutterTts.getDefaultVoice;
    if (voice != null) {
      print(voice);
    }
  }

  Future _setAwaitOptions() async {
    await flutterTts.awaitSpeakCompletion(true);
  }

  Future _speak() async {
    await flutterTts.setVolume(volume);
    await flutterTts.setSpeechRate(rate);
    await flutterTts.setPitch(pitch);

    if (text.isNotEmpty) {
      await flutterTts.speak(text);
    }
  }

  Future _stop() async {
    var result = await flutterTts.stop();
    if (result == 1) setState(() => ttsState = TtsState.stopped);
  }

  Future<void> _save() async {
    if (text.isNotEmpty) {
      try {
        final appDocDirectory = await getApplicationDocumentsDirectory();
        final filePath =
            '${appDocDirectory.path}/saved_text  - ${DateTime.now()}.txt';
        final file = File(filePath);

        if (text.isEmpty) throw Exception('Empty');
        await file.writeAsString(text);

        // Show a success dialog
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Text Saved'),
              content: const Text('The text has been saved successfully.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text('OK'),
                ),
              ],
            );
          },
        );
      } catch (error) {
        print('Error while saving text: $error');
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Error'),
              content: const Text('An error occurred while saving the text.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text('OK'),
                ),
              ],
            );
          },
        );
      }
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Empty Text'),
            content: const Text('The text is empty. Enter some text to save.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }
}
